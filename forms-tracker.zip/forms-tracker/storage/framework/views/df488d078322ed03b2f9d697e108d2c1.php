<section></section>
<section>
    <div style="width: 100%">
        <div class="columns seven">
            <h3><b> Form Tracking App</b></h3>
        </div>
        <div class="columns five align-right">
            
            <button>Guide</button>
        </div>
        <div class="columns twelve">
            <ul class="tabs">
                <li class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">
                    <a href="<?php echo e(URL::tokenRoute('home')); ?>">General Settings</a>
                </li>
                <li class="<?php echo e(request()->is('get-all-forms') ? 'active' : ''); ?>">
                    <a href="<?php echo e(URL::tokenRoute('getAllFormsData')); ?>">Forms </a>
                </li>
            </ul>
        </div>
    </div>
</section>
<?php /**PATH /home/hammadraja/Sites/forms-tracker/resources/views/header.blade.php ENDPATH**/ ?>