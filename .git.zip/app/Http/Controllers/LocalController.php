<?php

namespace App\Http\Controllers;

use App\Models\Local;
use App\Models\SaveFormRecords;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LocalController extends Controller
{
    public function local()
    {
        $shopName = Auth::user()->name;
        $fieldsRecords = Local::where('shopName', $shopName)->orderBy('position', 'ASC')->get();
        return view('page-one', compact('fieldsRecords'));
    }
    public function getRecords()
    {
        $shopName = Auth::user()->name;
        // $formRecords = SaveFormRecords::where('shopName', $shopName)->orderBy('id', 'ASC')->get();
        $formRecords = SaveFormRecords::where('shopName', $shopName)->distinct('sessionId')->get(['sessionId']);


        return view('page-two', compact('formRecords'));
    }

    public function getRecordsBySessionId(Request $request)
    {
        $shopName = Auth::user()->name;
        $sessionId = $request->id;
        $sessionIdRecords = SaveFormRecords::where(['sessionId' => $sessionId, 'shopName' => $shopName])->get();
        return view('page-three', compact('sessionIdRecords'));
    }


    public function saveFormFields(Request $request)
    {
        $shopName = Auth::user()->name;

        $fieldRecords = $request->json()->all();
        // echo "<pre>";
        // print_r($fieldRecords);
        // dd('die');
        $deletePrviousRecords = Local::where('shopName', $shopName)->delete();
        foreach ($fieldRecords as $field) {
            Local::create([
                'title' => $field['title'],
                'type' => $field['type'],
                'options' => $field['options'],
                'position' => $field['position'],
                'shopName' => $shopName,
            ]);
        }
        return response()->json(['status' => 200, 'message' => 'Records saved successfully']);
    }
    public function getFormFields(Request $request)
    {
        // dd($request->shopifyId);
        // $sessionIdRecords = SaveFormRecords::where('shopName',$request->shopName)->get();
        $customFields = Local::where(['shopName' => $request->shopName])->orderBy('position', 'ASC')->get();
        return response()->json(['status' => 200, 'forms' => $customFields]);
    }
    public function submitFieldsForm(Request $request)
    {
        $fields = (array)$request->all();
        unset($fields['shopName']); // unset from array
        unset($fields['sessionId']); // unset from array
        $shopName = $request['shopName'];
        $sessionId = $request['sessionId'];
        // echo "<pre>";
        // print_r($fields);
        // dd($sessionId);

        $sessionCheck = SaveFormRecords::where(['sessionId' => $sessionId, 'shopName' => $shopName])->distinct('sessionId')->first(['sessionId']);

        if ($sessionCheck == null) {  // for first time save
            foreach ($fields as $title => $value) {
                if (is_array($value) == true) {   // this is just for checkbox values implode
                    $value = implode(',', $value);
                }

                $index = explode('^', $title);
                $indexCount = count($index);
                if ($indexCount != 3) {
                    continue;
                }

                $customFields = Local::where(['id' => $index[2], 'shopName' => $shopName])->first();
                // dd($index[2]." -dfdfsd");
                SaveFormRecords::create([
                    'title' => str_replace("_", " ", $index[0]), // for title
                    'value' => $value,
                    'options' => ($customFields->options == null ? null : $customFields->options),
                    'type' => $index[1],
                    'sessionId' => $sessionId,
                    'shopName' => $shopName,
                ]);
            }

            return response()->json(['status' => 200, 'message' => 'Records saved successfully']);
        } else {
            foreach ($fields as $title => $value) {
                if (is_array($value) == true) {   // this is just for checkbox values implode
                    $value = implode(',', $value);
                }

                $index = explode('^', $title);
                $indexCount = count($index);
                if ($indexCount != 3) {
                    continue;
                }

                $customFields = SaveFormRecords::where(['id' => $index[2], 'shopName' => $shopName])->first();
                // dd($customFields);
                SaveFormRecords::updateOrCreate(['id' => $index[2]], [
                    'title' => str_replace("_", " ", $index[0]), // for title
                    'value' => $value,
                    'options' => ($customFields->options == null ? null : $customFields->options),
                    'type' => $index[1],
                    'sessionId' => $sessionId,
                    'shopName' => $shopName,
                ]);
            }

            return response()->json(['status' => 201, 'message' => 'Records updated successfully']);
        }
    }
}