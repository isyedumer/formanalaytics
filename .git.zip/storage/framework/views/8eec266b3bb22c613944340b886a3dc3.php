<?php $__env->startSection('content'); ?>
    <!-- You are: (shop domain name) -->
    <section>
    </section>
    
    <section style="padding-left: 20px">
        <div style="width: 100%">
            
            <div class="columns eleven">
                <h3><b>Dashboard</b></h3>
            </div>
        </div>
    </section>

    <div class="row align-right">
        <div class="col-12">
            <a href="<?php echo e(URL::tokenRoute('localTesting')); ?>" class="button">Design Form</a>
    </div>
    </div>
    <section>
      
        <article>
            <div class="card columns six">
                <p>Total form views</p>
                <p> <?php echo e($totalFormViews); ?></p>
            </div>
            <div class="card columns six">
                <p>Total form fills</p>
                <p><?php echo e($totalFormsFill); ?></p>
            </div>
            <div class="card columns six">
                <p>Form fill conversion rate</p>
                <p><?php echo e($fillConversionsRate); ?>%</p>
            </div>
        </article>
    </section>

    <section>
        <article>
            <div class="card columns six">
                <p>Total unfinished submissions</p>
                <p><?php echo e($totalunfinishedSubmissions); ?></p>
            </div>
            <div class="card columns six">
                <p>Total complete submissions</p>
                <p><?php echo e($totalFormSubmissions); ?></p>
            </div>
            <div class="card columns six">
                <p>Form complete conversion Rate</p>
                <p><?php echo e($completeConversionsRate); ?>%</p>
            </div>
        </article>
    </section>

    <section>
        <card class="full-width">
        <table>

            <thead>
                <tr>
                    <th>Forms</th>
                    <th>Submissions</th>
                    <th>View</th>
                </tr>
            </thead>

            <tbody>
            <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($key); ?></th>
                    <th><?php echo e($form); ?></th>
                    <th><a href="<?php echo e(URL::tokenRoute('form.view', ['form' => $key])); ?>" class="button secondary icon-preview"></a></th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
        </table>
        </card>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>

    <script>
        // actions.TitleBar.create(app, { title: 'Welcome' });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shopify-app::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/natureva/public_html/tasknew/resources/views/welcome.blade.php ENDPATH**/ ?>