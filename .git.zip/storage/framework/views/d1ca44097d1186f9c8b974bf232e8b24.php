<?php $__env->startSection('content'); ?>
    <!-- You are: (shop domain name) -->
    <section>
    </section>
    <section>
        <div style="width: 100%">
            <div class="columns one">
                <a href="<?php echo e(URL::tokenRoute('home')); ?>">
                    <button class="secondary icon-arrow-left"></button>
                </a>
            </div>
            <div class="columns eleven">
                <h3><b>Form Detail</b></h3>
            </div>
        </div>
    </section>
    <section>
        <article>
            <div class="card columns six">
                <p>Total form views</p>
                <p> <?php echo e($totalFormViews); ?></p>
            </div>
            <div class="card columns six">
                <p>Total form fills</p>
                <p><?php echo e($totalFormsFill); ?></p>
            </div>
            <div class="card columns six">
                <p>Form fill conversion rate</p>
                <p><?php echo e($fillConversionsRate); ?>%</p>
            </div>
        </article>
    </section>

    <section>
        <article>
            <div class="card columns six">
                <p>Total unfinished submissions</p>
                <p><?php echo e($totalunfinishedSubmissions); ?></p>
            </div>
            <div class="card columns six">
                <p>Total complete submissions</p>
                <p><?php echo e($totalFormSubmissions); ?></p>
            </div>
            <div class="card columns six">
                <p>Form complete conversion Rate</p>
                <p><?php echo e($completeConversionsRate); ?>%</p>
            </div>
        </article>
    </section>

    <section>
        <article>
            <div class="card columns six">
                <p>Total consent check</p>
                <p><?php echo e($totalConsentCheck); ?></p>
            </div>
            <div class="card columns six">
                <p>Percentage consent check </p>
                <p><?php echo e($consentConversion); ?>%</p>
            </div>
        </article>
    </section>

    <section>
        <card class="full-width">
        <table>

            <thead>
                <tr>
                    <th>Fields</th>
                    <th>Submissions</th>
                </tr>
            </thead>

            <tbody>
            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($key); ?></th>
                    <th><?php echo e($field); ?></th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
        </table>
        </card>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>

    <script>
        actions.TitleBar.create(app, { title: 'Welcome' });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shopify-app::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/natureva/public_html/tasknew/resources/views/form_details_page.blade.php ENDPATH**/ ?>